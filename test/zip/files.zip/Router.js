// Written in this round about way for babel-transform-imports
import Router from "react-router/es/Router";

export default Router;