// Written in this round about way for babel-transform-imports
import withRouter from "react-router/es/withRouter";

export default withRouter;