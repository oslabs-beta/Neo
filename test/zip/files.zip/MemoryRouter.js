// Written in this round about way for babel-transform-imports
import MemoryRouter from "react-router/es/MemoryRouter";

export default MemoryRouter;