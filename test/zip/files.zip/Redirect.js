// Written in this round about way for babel-transform-imports
import Redirect from "react-router/es/Redirect";

export default Redirect;