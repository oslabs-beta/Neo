// Written in this round about way for babel-transform-imports
import Switch from "react-router/es/Switch";

export default Switch;