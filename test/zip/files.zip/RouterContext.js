// Written in this round about way for babel-transform-imports
import RouterContext from "react-router/es/RouterContext";

export default RouterContext;