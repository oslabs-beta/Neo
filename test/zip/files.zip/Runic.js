const set = require('regenerate')();
set.addRange(0x16A0, 0x16EA).addRange(0x16EE, 0x16F8);
exports.characters = set;
