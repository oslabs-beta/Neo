const set = require('regenerate')();
set.addRange(0x2FF2, 0x2FF3);
exports.characters = set;
