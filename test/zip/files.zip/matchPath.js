// Written in this round about way for babel-transform-imports
import matchPath from "react-router/es/matchPath";

export default matchPath;