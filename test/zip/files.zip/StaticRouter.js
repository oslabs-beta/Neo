// Written in this round about way for babel-transform-imports
import StaticRouter from "react-router/es/StaticRouter";

export default StaticRouter;