// Written in this round about way for babel-transform-imports
import Prompt from "react-router/es/Prompt";

export default Prompt;