const set = require('regenerate')();
set.addRange(0x10450, 0x1047F);
exports.characters = set;
