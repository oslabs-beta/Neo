// Written in this round about way for babel-transform-imports
import Route from "react-router/es/Route";

export default Route;