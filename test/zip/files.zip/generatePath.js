// Written in this round about way for babel-transform-imports
import generatePath from "react-router/es/generatePath";

export default generatePath;